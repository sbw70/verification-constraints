# MD-001 review handoff

This ZIP contains the complete existing MULTI_DOMAIN_001 project, preserved
without modifying source, documentation, configuration, evidence, or manifests.
All project files, including existing test evidence and manifests, are under
MULTI_DOMAIN_001/. This separate handoff note is outside that validated tree.

## Corrected hardware inventory supplied by the operator

- Existing working switch: 5-port TP-Link unmanaged switch; all five ports occupied.
- New switch: NETGEAR GS308Ev4, 8-port managed; powered on but disconnected.
- Protectli Vault: WAN igb0 and LAN igb1 connected; OPT1 igb2 and OPT2 igb3
  physically empty but already configured.
- OmniBook: Wi-Fi only; no Ethernet port.

## Deployment discrepancy requiring review

The operator flags that the prior deployment proposal assumed a fifth Vault
interface, which does not exist. The Vault has the four interfaces listed above.
Any fifth-interface assumption is invalid. The retained deployment proposal's
unresolved dedicated-trunk and wired operator-management assumptions must be
reconciled with this corrected inventory before an applicable plan is approved.
Physically empty OPT1/OPT2 ports are already configured and must not be treated
as unconfigured or safe to repurpose without inspecting their assignments.
The existing TP-Link switch has no spare ports. The OmniBook cannot connect
directly to a wired management port with its present hardware.

This correction does not amend the validated project. Review its retained
DEPLOYMENT_PLAN.md and ROLLBACK.md as historical proposed plans, subject to the
corrected inventory and unresolved prerequisites above. No live network
configuration was inspected or changed as part of packaging.

## Scope and status

Read MULTI_DOMAIN_001/COMPLETION.md for the recorded STOP 1 result and limitations.
Existing simulation evidence is retained as-is; no evidence was regenerated.
No deployment, network configuration, physical test, or ESP actuation was run.
Packaging and archive-integrity checks only were performed. STOP after packaging.
